Oasis Zen — simple responsive homepage

How to use:
1. Create a folder named "oasis-zen".
2. Save the files index.html, styles.css, script.js into that folder.
3. Create a subfolder "assets" and put your hero image there with filename: assets/hero.jpg
   - If you uploaded Image 1 in this chat, download it and save as assets/hero.jpg
4. Open index.html in a browser.

Create a ZIP (macOS / Linux):
  cd path/to
  zip -r oasis-zen.zip oasis-zen/

Create a ZIP (Windows PowerShell):
  Compress-Archive -Path .\oasis-zen\ -DestinationPath .\oasis-zen.zip

If you want a single HTML file (inline CSS+JS and optional base64 image) or if you prefer I produce a ZIP base64 string here for direct download, tell me and mình sẽ tạo tiếp.